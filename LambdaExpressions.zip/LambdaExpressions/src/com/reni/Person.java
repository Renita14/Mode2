package com.reni;

public class Person {
int age;
String name;
public Person(int age, String name) {
	super();
	this.age = age;
	this.name = name;
}
}
