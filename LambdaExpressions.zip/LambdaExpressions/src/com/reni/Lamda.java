package com.reni;

public interface Lamda {
	public void run();
	public void show(int a);
	public void display(int a,int b);
	public void disp(int a,int b,int c);
	
	
	}


