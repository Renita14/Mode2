package com.reni;
interface La{
	 int add(int a,int b,int c);  
}
public class Expression {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		La ad1=(a,b,c)->(a+b+c);  
		System.out.println("The addition method:");
        System.out.println(ad1.add(10,20,30));  
}
}
