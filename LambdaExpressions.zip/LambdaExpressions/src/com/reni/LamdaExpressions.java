package com.reni;

import java.util.ArrayList;
import java.util.List;

public class LamdaExpressions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person p1 = new Person(20, "anbu");
		Person p2 = new Person(30, "anu");
		List<Person> list = new ArrayList<Person>();
		list.add(p1);
		list.add(p2);
		list.forEach(i -> {if (i.name.startsWith("a"))System.out.println(i.name);
		});
	}
	/*
	 * List<String> list = new ArrayList<String>(); list.add("ankit");
	 * list.add("mayank"); list.add("irfan"); list.add("jai");
	 * 
	 * list.forEach((n) -> System.out.println(n)); }
	 */

}
