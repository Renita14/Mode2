package com.reni;
interface Lam{
	public void run();
}

	public class Generic{
	public static void main (String args[]){
		int width=10;
		
		 Lam d2=()->{  
			 System.out.println("draw "  +width);
		 };
	
		 d2.run();
	}
	}


