package com.reni;

import java.util.*; 

class PeekDemo { 
  
    // Driver code 
    public static void main(String[] args) 
    { 
  
        // Creating a list of Integers 
        List<Integer> list = Arrays.asList(0, 2, 4, 6, 8, 10); 
  
        // Using peek without any terminal 
        // operation does nothing. Hence this 
        // code will produce no output. 
        list.stream().peek(System.out::println); 
    } 
} 
