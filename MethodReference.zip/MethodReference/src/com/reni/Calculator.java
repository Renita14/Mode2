package com.reni;

interface Sayable{  
    void say();  
}  
public class Calculator{  
    public static void saySomething(){  
        System.out.println("method reference example");  
    }  
    public static void main(String[] args) {  
        // Referring static method  
        Sayable sayable = Calculator::saySomething;  
        // Calling interface method  
        sayable.say();  
    }  
}  