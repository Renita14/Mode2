package com.bookticket.BookingTrainTicket.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bookticket.BookingTrainTicket.Dao.BookTrainTicketDao;
import com.bookticket.BookingTrainTicket.Dao.PassengerDao;
import com.bookticket.BookingTrainTicket.Exception.BookingIdNotFoundException;
import com.bookticket.BookingTrainTicket.Model.BookTrainTicket;
import com.bookticket.BookingTrainTicket.Model.PassengerDetails;

@Service
public class PassengerService {
	
@Autowired
PassengerDao passengerDao;

@Autowired
BookTrainTicketDao bookTrainTicketDao;

public List<PassengerDetails> addPassengerDetails(String bookingId,PassengerDetails[] passengerDetails) {
	List<PassengerDetails> passengerInfo = new ArrayList<PassengerDetails>();
	Optional<BookTrainTicket> booking= bookTrainTicketDao.findById(bookingId);
	if(!booking.isPresent()) {
		throw new BookingIdNotFoundException("Booking ID is Not Found");
	}else {
		
	System.out.println("seats:"+booking.get().getNoOftickets());
	for (int i = 0; i < booking.get().getNoOftickets(); i++) {
		int auto = (int) (Math.random() * 100 + 1);
		String PNR = "PNR" + auto;
		passengerDetails[i].setPNR(PNR);
		passengerDetails[i].getPassengerName();
		passengerDetails[i].getPassengerAge();
		passengerDetails[i].getUserId();
		passengerInfo.add(passengerDetails[i]);
		passengerDao.save(passengerDetails[i]);
	}
	return passengerInfo;
	}
}

public String cancellingTrainTicketByPnr(String PNR) {
	Optional<PassengerDetails> pnrId= passengerDao.findById(PNR);
	if(!pnrId.isPresent()) {
		throw new BookingIdNotFoundException("Booking ID is Not Found");
	}else {
		passengerDao.deleteById(PNR);
	return "ticket cancelled";
}

}
}
