package com.searchTrain.searchTrain.model;
import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="booktrain_ticket")
public class BookTrainTicket {
	@Id
private String bookingId;
	 
	private String userId;
	private int noOftickets;
	private String fromPlace;
	private String toPlace;
	private LocalDate date;
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getNoOftickets() {
		return noOftickets;
	}
	public void setNoOftickets(int noOftickets) {
		this.noOftickets = noOftickets;
	}
	public String getFromPlace() {
		return fromPlace;
	}
	public void setFromPlace(String fromPlace) {
		this.fromPlace = fromPlace;
	}
	public String getToPlace() {
		return toPlace;
	}
	public void setToPlace(String toPlace) {
		this.toPlace = toPlace;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}

}
