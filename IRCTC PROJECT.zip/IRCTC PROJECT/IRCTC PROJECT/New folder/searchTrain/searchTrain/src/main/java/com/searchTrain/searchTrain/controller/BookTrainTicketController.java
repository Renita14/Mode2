package com.searchTrain.searchTrain.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.searchTrain.searchTrain.model.BookTrainTicket;
import com.searchTrain.searchTrain.service.BookTrainTicketService;

@RestController
public class BookTrainTicketController {
	@Autowired
	BookTrainTicketService bookTrainTicketService;

	@PostMapping(value = "user/book/trainticket")
	public BookTrainTicket bookTrainTicket(@RequestBody BookTrainTicket bookTrainTicket) {
		return bookTrainTicketService.bookTrainTicket(bookTrainTicket);
	}

	@GetMapping(value = "user/search")
	public BookTrainTicket findNoOfTickets(@RequestParam("bookingId") String bookingId,
			@RequestParam("userId") String userId) {
		return bookTrainTicketService.findNoOfTickets(bookingId, userId);
	}

	@GetMapping(value = "user/search/userId")
	public List<BookTrainTicket> findNoOfTicketsByUserId(@RequestParam("userId") String userId) {
		return bookTrainTicketService.findNoOfTicketsByUserId(userId);
	}

	/*
	 * @RequestMapping(value = "/user/book/ticket", method = RequestMethod.POST)
	 * 
	 * public String bookTickets(@RequestBody BookTrainTicket bookTrainTicket) {
	 * return bookTrainTicketService.bookTickets(bookTrainTicket);
	 * 
	 * }
	 */}
