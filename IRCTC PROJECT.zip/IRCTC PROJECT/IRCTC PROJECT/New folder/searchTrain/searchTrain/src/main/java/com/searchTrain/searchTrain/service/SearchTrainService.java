package com.searchTrain.searchTrain.service;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.searchTrain.searchTrain.ExceptionHandling.TrainIdNotFoundException;
import com.searchTrain.searchTrain.ExceptionHandling.TrainsAreNotFoundException;
import com.searchTrain.searchTrain.dao.SearchTrainDao;
import com.searchTrain.searchTrain.model.SearchTrain;


@Service

public class SearchTrainService {
	@Autowired
	SearchTrainDao searchTrainDao;

	public Optional<SearchTrain> findTrain(String fromPlace, String toPlace, LocalDate date) {
		Optional<SearchTrain> trainDetails = searchTrainDao.findTrain(fromPlace, toPlace, date);
		if (!trainDetails.isPresent()) {
			throw new TrainsAreNotFoundException("Train are not available for this date-"+date);
		} else {
			return trainDetails;
		}

		
	}

	public Optional<SearchTrain> findByTrainId(Integer trainId) {

		Optional<SearchTrain> train = searchTrainDao.findById(trainId);
		if (!train.isPresent()) {
			throw new TrainIdNotFoundException("Sorry Train is Invalid" + "-trainId" + trainId);
		} else {
			return train;
		}

	}

}
