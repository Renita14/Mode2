package com.searchTrain.searchTrain.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.searchTrain.searchTrain.model.BookTrainTicket;
import com.searchTrain.searchTrain.model.Passenger;
import com.searchTrain.searchTrain.service.PassengerService;

@RestController
public class PassengerController {
	@Autowired
	PassengerService passengerService;

	/*
	 * @PostMapping(value="/passenger/add") public String
	 * addPassengerDetails(@RequestBody Passenger passenger) { BookTrainTicket
	 * bookTrainTicket=new BookTrainTicket(); bookTrainTicket.getBookingId(); return
	 * passengerService.addPassengerDetails(passenger); }
	 */	@GetMapping(value="passenger/search/{userId}")
	public List<Passenger> passengerDetails(@RequestParam("userId") String userId){
		List<Passenger> list=passengerService.passengerDetails(userId);
		return list;
	}

}
