package com.train.IRCTCApplication.dto;

import java.time.LocalDate;

public class BookingDto {

	private String bookingId;

	private String userId;
	private int noOftickets;
	private int trainId;
	private LocalDate date;
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getNoOftickets() {
		return noOftickets;
	}
	public void setNoOftickets(int noOftickets) {
		this.noOftickets = noOftickets;
	}
	public int getTrainId() {
		return trainId;
	}
	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	
}
