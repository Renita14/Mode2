package com.train.IRCTCApplication.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.train.IRCTCApplication.dto.PassengerDetails;


@Service
public class PassengerService {
	@Autowired
	RestTemplate restTemplate;
	

	public List<PassengerDetails> addPassengerDetails(String bookingId,PassengerDetails[] passengerDetails) {
		return restTemplate.postForObject("http://localhost:8093/user/add/passenger/{bookingId}", passengerDetails, List.class,bookingId);
}
	public String cancellingTrainTicketByPnr(String PNR) {
        restTemplate.delete("http://localhost:8093/user/ticket/cancelByPnr/{PNR}",PNR);
        return "ticket cancelled";
	}
}
