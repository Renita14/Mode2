package com.train.IRCTCApplication.Controller;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.train.IRCTCApplication.dto.SearchTrainDto;
import com.train.IRCTCApplication.service.SearchService;

@RestController
public class SearchController {

	
	@Autowired
	SearchService searchService;
	
	@GetMapping("/user/trains/{fromPlace}/{toPlace}/{date}")
	public SearchTrainDto getTrainDetails(@PathVariable("fromPlace") String fromPlace,
			@PathVariable("toPlace") String toPlace,
			@PathVariable("date") @DateTimeFormat(iso = ISO.DATE) LocalDate date){
		return searchService.findTrain(fromPlace, toPlace, date);
	}
	
	@GetMapping(value = "/user/trains/{trainId}/{date}")
	public SearchTrainDto searchTrain(@PathVariable("trainId") Integer trainId,@PathVariable("date") LocalDate date) {
		return searchService.searchTrain(trainId,date);
	}
}
