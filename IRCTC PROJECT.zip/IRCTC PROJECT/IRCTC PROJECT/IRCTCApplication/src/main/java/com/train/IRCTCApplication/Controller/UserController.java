package com.train.IRCTCApplication.Controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.train.IRCTCApplication.dto.LoginDto;
import com.train.IRCTCApplication.model.User;
import com.train.IRCTCApplication.service.UserService;

@RestController
public class UserController {
	

	@Autowired
	UserService userService;

	@PostMapping(value = "/user/add")
	public String addUserDetails(@RequestBody User user) {
		return userService.addUserDetails(user);
	}

	@PutMapping(value = "user/login/{userId}")
	public Optional<User> loginUser(@RequestBody LoginDto loginDto, @PathVariable(value = "userId") String userId) {
		return userService.loginUser(loginDto, userId);
	}

}
