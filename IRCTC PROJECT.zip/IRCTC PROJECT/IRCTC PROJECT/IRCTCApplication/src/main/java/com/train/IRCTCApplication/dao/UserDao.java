package com.train.IRCTCApplication.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.train.IRCTCApplication.dto.LoginDto;
import com.train.IRCTCApplication.model.User;

@Repository
public interface UserDao extends CrudRepository<User, String> {

	@Query(value="select user_name,password from user where user_name=?1 and password=?2",nativeQuery = true)
	public Optional<LoginDto> findByUserName(String userName , String password);
}
